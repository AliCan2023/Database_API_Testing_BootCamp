create view SHORTLASTNAME as
select substr(LAST_NAME, 1, 3) as shortLastName
from EMPLOYEES
/

