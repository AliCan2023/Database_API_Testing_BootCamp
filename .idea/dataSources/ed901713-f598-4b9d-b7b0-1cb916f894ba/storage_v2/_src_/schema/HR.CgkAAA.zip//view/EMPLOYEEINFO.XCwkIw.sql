create view EMPLOYEEINFO as
select first_name||' '||last_name||' : '||lower(email||'@gmail.com') as "Email Addresses" from employees
/

