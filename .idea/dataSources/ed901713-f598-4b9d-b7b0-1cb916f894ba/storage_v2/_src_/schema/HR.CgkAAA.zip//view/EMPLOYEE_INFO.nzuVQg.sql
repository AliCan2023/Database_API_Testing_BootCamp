create view EMPLOYEE_INFO as
select first_name||' '||last_name as FULL_NAME from employees
/

